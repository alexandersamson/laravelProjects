<span class="btn-group btn-xs-table">
    <a title="Approve" href="/posts/<?php echo e($post->id); ?>" class="btn btn-sm btn-xs-table btn-success">&nbsp;A&nbsp;</a>
    <a title="View" href="/posts/<?php echo e($post->id); ?>" class="btn btn-sm btn-xs-table btn-outline-primary">&nbsp;V&nbsp;</a>
    <a title="Edit" href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-sm btn-xs-table btn-outline-secondary">&nbsp;E&nbsp;</a>
    <a title="Delete" href="#" data-toggle="modal" data-category="posts" data-domid="posts<?php echo e($post->id); ?>" data-id="<?php echo e($post->id); ?>" data-name="<?php echo e($post->title); ?>" data-target="#genericDeleteModal" class="btn btn-sm btn-xs-table btn-outline-danger">&nbsp;D&nbsp;</a>
</span><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/includes/caved-buttons.blade.php ENDPATH**/ ?>