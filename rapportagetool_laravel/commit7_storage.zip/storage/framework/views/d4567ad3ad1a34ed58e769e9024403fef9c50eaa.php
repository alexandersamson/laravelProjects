<?php $__env->startSection('generic-form-model-content'); ?>



<?php $__env->stopSection(); ?>














<?php echo $__env->make('modals.generic-form-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/modals/includes/client-selector.blade.php ENDPATH**/ ?>