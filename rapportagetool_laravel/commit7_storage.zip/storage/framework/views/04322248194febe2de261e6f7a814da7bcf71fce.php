<?php $__env->startSection('content'); ?>

    <h1>Create Casefile</h1>
    <?php echo Form::open(['action' => 'CasefilesController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <div class="form-group">
            <?php echo e(Form::button('CaseCode: '.$data['casecode'].' <span id="caseCodeCopyBadge" class="text-light badge badge-primary font-weight-light">Click to copy</span>', ['data-clipboard-return-id-target'=> 'caseCodeCopyBadge', 'data-clipboard-text'=> $data['casecode'], 'type' => 'button', 'class' => 'btn btn-light btn-sm  btnClipboard'] )); ?>

            <?php echo e(Form::hidden('casecode', $data['casecode'])); ?>


        </div>
        <div class="form-group">
            <?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'Title (max 32 characters)'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('description', 'Description')); ?>

            <?php echo e(Form::textarea('description', '', ['id' => 'article-ckeditor', 'class' => 'form-control', 'placeholder' => 'Body message'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('case-state', 'Status')); ?>

            <?php echo $__env->make('casefiles.elements.select-case-state-dropdown', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="form-group">
            <?php echo e(Form::label('assignees', 'Assignees')); ?>

            <div class="card mb-0 shadow-sm">
                <div class="row" id="assigneesContainerA">
                    <div class="col-sm-3">
                        <div class="p-1">
                            <button type="button" class="btn btn-primary btn-block btn-md genericFormModalBtn" data-toggle="modal" data-save="addLeadInvestigator" data-cmd="getAjax" data-url="ajaxGetLeadInvestigatorSelectList" data-header="Add Lead Investigator" data-target="#genericFormModal">
                                Select Lead Investigator
                            </button>
                            <div class="mt-1" id="ajax-output-addLeadInvestigator">
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="p-1">
                            <button type="button" class="btn btn-primary btn-block btn-md genericFormModalBtn" data-toggle="modal" data-save="addInvestigators" data-cmd="getAjax" data-url="ajaxGetInvestigatorSelectList" data-header="Add Investigator" data-target="#genericFormModal">
                                Select Investigators
                            </button>
                            <div class="mt-1" id="ajax-output-addInvestigators">
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="p-1">
                            <button type="button" class="btn btn-primary btn-block btn-md genericFormModalBtn" data-toggle="modal" data-save="addClients" data-cmd="getAjax" data-url="ajaxGetClientSelectList" data-header="Add Client"  data-target="#genericFormModal">
                                 Select Clients
                            </button>
                            <div class="mt-1" id="ajax-output-addClients">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-group">
            <?php echo e(Form::file('cover_image')); ?>

        </div>
        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

        <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/casefiles/create.blade.php ENDPATH**/ ?>