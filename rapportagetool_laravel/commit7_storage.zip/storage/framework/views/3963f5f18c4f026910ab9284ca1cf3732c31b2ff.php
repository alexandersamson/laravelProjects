<?php $__env->startSection('content'); ?>
    <a href="/casefiles" class="btn btn-outline-dark">Go back</a>
    <h1><?php echo e($casefile->title); ?></h1>

    <div>
        <?php echo $casefile->description; ?>

    </div>
    <hr>
    <small>Written on <?php echo e($casefile->created_at); ?><?php if($casefile->created_at != $casefile->updated_at): ?> | Last modified on <?php echo e($casefile->updated_at); ?><?php endif; ?> | By: <?php echo e($casefile->user_id); ?></small>
    <hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/casefiles/show.blade.php ENDPATH**/ ?>