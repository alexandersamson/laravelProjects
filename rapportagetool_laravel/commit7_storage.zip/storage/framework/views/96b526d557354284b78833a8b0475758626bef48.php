<?php $__env->startSection('content'); ?>
    <a href="/users" class="btn btn-outline-dark">&lt; Back to users</a>
    <div class="row">
        <div class="col-lg-8 col-md-12">
            <div class="card">
                <div class="card-body">
                    <div align="center">
                        <img alt="cover image" width="" src="/images/users/profilepicture/<?php echo e($data['user']->id); ?>/profilepicture">
                        <h5 class="card-title"><?php echo e($data['user']->name); ?></h5>
                        <h6 class="card-subtitle mb-2 text-muted"><a href="mailto:<?php echo e($data['user']->email); ?>"><?php echo e($data['user']->email); ?></a> | <a href="tel:<?php echo e($data['user']->phone); ?>"><?php echo e($data['user']->phone); ?></a></h6>
                        <small class="card-subtitle mb-2 text-muted">
                            <?php if((new\App\Http\Controllers\PermissionsController)->getPermissionsTextArray($data['user']->permission) > 0): ?>
                                <?php $__currentLoopData = (new\App\Http\Controllers\PermissionsController)->getPermissionsTextArray($data['user']->permission); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!$loop->first): ?>
                                        |&nbsp;
                                    <?php endif; ?>
                                    <span class="text-dark"><?php echo e($permission); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </small>
                    </div>
                    <p class="card-text">

                    </p>
                    <?php echo $__env->make('includes.created-by-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/users/profile.blade.php ENDPATH**/ ?>