<small>
    <?php if(isset($data['createdAt']) || isset($data['creator'])): ?>
        Created
        <?php if(isset($data['createdAt'])): ?>
            at <?php echo e($data['createdAt']->format('d/m/Y H:i')); ?>

        <?php endif; ?>
        <?php if(isset($data['creator'])): ?>
            <span class="text-nowrap"> by <a href="/users/<?php echo e($data['creator']->id); ?>"><?php echo e($data['creator']->name); ?></a></span>
        <?php endif; ?>
    <?php endif; ?>
    <?php if((isset($data['createdAt']) || isset($data['creator'])) && (isset($data['modifiedAt']) || isset($data['modifier']))): ?>
        &nbsp;|&nbsp;
    <?php endif; ?>
    <?php if(isset($data['modifiedAt']) || isset($data['modifier'])): ?>
        Last edit
        <?php if(isset($data['modifiedAt'])): ?>
            at <?php echo e($data['modifiedAt']->format('d/m/Y H:i')); ?>

        <?php endif; ?>
        <?php if(isset($data['modifier'])): ?>
                <span class="text-nowrap"> by <a href="/users/<?php echo e($data['modifier']->id); ?>"><?php echo e($data['modifier']->name); ?></a></span>
        <?php endif; ?>
    <?php endif; ?>
</small><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/includes/created-by-footer.blade.php ENDPATH**/ ?>