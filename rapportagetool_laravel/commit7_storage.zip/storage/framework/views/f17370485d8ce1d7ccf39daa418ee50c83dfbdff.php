<div class="modal fade" id="testModal"
     tabindex="-1" role="dialog"
     aria-labelledby="testModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="testModalLabel">Testing AJAX/MySQL</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>
                    Initiating test...
                </p>
            </div>
            <div class="modal-footer">
                <button type="button"
                        class="btn btn-primary"
                        data-dismiss="modal">Dismiss</button>
                <span class="pull-right">
        </span>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/modals/testmodal.blade.php ENDPATH**/ ?>