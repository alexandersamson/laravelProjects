<?php if(count($users) > 0): ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="investigator<?php echo e($user[0]->id); ?>">
            <span id="investigator<?php echo e($user[0]->id); ?>" class="mb-1 btn-group btn-group-sm">
                <button type="button" id="LeadInv<?php echo e($user[0]->id); ?>" class="btn btn-outline-info" data-toggle="modal"
                        data-save="null" data-cmd="infoUser" data-url="<?php echo e($user[0]->id); ?>"
                        data-header="<?php echo e($user[0]->user); ?> | Contact details"  data-target="#genericInfoModal">@</button>
                <button type="button" class="btn btn-secondary"><?php echo e($user[0]->name); ?></button>
                <button type="button" data-url="#investigator<?php echo e($user[0]->id); ?>" data-container="#assigneesContainerA" class="btn btn-outline-danger btnDeleteItem">&times;</button>
            </span>
            <br>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/casefiles/elements/select-investigators.blade.php ENDPATH**/ ?>