<?php $__env->startSection('content'); ?>
    <h1>Casefiles</h1>
    <?php echo $__env->make('includes.casefile-card-title', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(count($data['casefiles']) > 0): ?>
        <?php $__currentLoopData = $data['casefiles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $casefile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-0 shadow-sm">
                <div class="row">
                    <div class="col-sm-2">
                        <div class="btn-group btn-group-sm">
                            <a class="btn btn-sm btn-success" href="/casefiles/<?php echo e($casefile->id); ?>"><?php echo e($casefile->casecode); ?></a>
                            <button type="button" class="btn btn-success btn-sm dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="sr-only">Options</span>
                            </button>
                            <div class="dropdown-menu">
                                <h6 class="dropdown-header text-center"><?php echo e($casefile->casecode); ?></h6>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="/casefiles/<?php echo e($casefile->id); ?>">View Casefile</a>
                                <a class="dropdown-item text-primary" href="#">Add note</a>
                                <a class="dropdown-item text-primary" href="#">Add file</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#">Copy CaseCode</a>
                                <a class="dropdown-item" href="#">Copy CaseCode Staff link</a>
                                <a class="dropdown-item" href="#">Copy CaseCode Client link</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#">Hide Casefile</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item text-danger" href="#">Delete Casefile</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="btn-group btn-group-sm">
                            <button type="button" class="btn btn-sm btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class=""><?php echo e($data['casestates'][$casefile->case_state_index-1]->name); ?></span>
                            </button>
                            <div class="dropdown-menu">
                                <h6 class="dropdown-header text-center">Set <?php echo e($casefile->casecode); ?> status to</h6>
                                <div class="dropdown-divider"></div>
                                <?php $__currentLoopData = $data['casestates']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caseState): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a id="case-state-<?php echo e($caseState['id']); ?>" class="dropdown-item <?php if($casefile->case_state_index == $caseState['id']): ?> active <?php endif; ?> " href="#"><?php echo e($caseState['name']); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        
                    </div>
                    <div class="col-sm-2">
                        <small><span class="text-sm-left align-content-center"><?php echo e(\Illuminate\Support\Str::limit($casefile->name,22)); ?></span></small>
                    </div>
                    <div class="col-md-2">
                        <h6>
                            <?php $__currentLoopData = $data['assignedClients'][$casefile->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="font-weight-normal <?php if($assignee->is_first_contact): ?>badge badge-dark btn-sm <?php elseif($assignee->can_read_only): ?> badge badge-light text-muted btn-sm <?php else: ?> badge badge-secondary btn-sm <?php endif; ?>" href="clients/<?php echo e($assignee->client->id); ?>"><?php echo e($assignee->client->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </h6>
                    </div>
                    <div class="col-sm-4">
                        <h6>
                            <?php $__currentLoopData = $data['assignedUsers'][$casefile->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="font-weight-normal <?php if($assignee->is_lead_investigator): ?>badge badge-primary btn-sm <?php elseif($assignee->can_read_only): ?> badge badge-light text-muted btn-sm <?php else: ?> badge badge-secondary btn-sm <?php endif; ?>" href="users/<?php echo e($assignee->user->id); ?>"><?php echo e($assignee->user->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </h6>

                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($data['casefiles']->links()); ?>

    <?php else: ?>
        <p>No casefiles found</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/casefiles/dashboard.blade.php ENDPATH**/ ?>