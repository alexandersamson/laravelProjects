<div class="modal fade" id="addUserModal"
     tabindex="-1" role="dialog"
     aria-labelledby="addUserModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="addUserModalLabel">Add User</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php echo $__env->yieldContent('user-modal-body-content'); ?>
            <div class="modal-footer">
                <button type="button"
                        class="btn btn-secondary"
                        data-dismiss="modal">Cancel</button>
                <span class="pull-right">
          <button type="button" class="btn btn-primary">
            Save
          </button>
        </span>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/modals/generic-form-modal.blade.php ENDPATH**/ ?>