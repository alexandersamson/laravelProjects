<div class="modal fade" id="genericFormModal"
     tabindex="-1" role="dialog"
     aria-labelledby="genericFormModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="genericFormModalLabel">Add User</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Loading...
            </div>
            <div class="modal-footer">
                <button type="button"
                        class="btn btn-secondary modalCancelBtn"
                        data-dismiss="modal">Cancel</button>
                <span class="pull-right">
          <button type="button" data-save="null" id="genericFormModalSaveBtn" class="btn btn-primary modalSaveBtn">
            Save
          </button>
        </span>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/modals/generic-form-modal.blade.php ENDPATH**/ ?>