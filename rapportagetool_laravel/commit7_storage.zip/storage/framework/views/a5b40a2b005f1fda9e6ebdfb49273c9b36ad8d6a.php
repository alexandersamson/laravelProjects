<?php $__env->startSection('content'); ?>

    <h1>About page</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/pages/about.blade.php ENDPATH**/ ?>