<?php if(count($data['casefiles_recent'])> 0): ?>
    <small><table class="table table-sm">
        <?php $__currentLoopData = $data['casefiles_recent']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $casefile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="casefiles<?php echo e($casefile->id); ?>">
                <td class="overflow-hidden">
                    <?php echo e(\Illuminate\Support\Str::limit($casefile->name,27)); ?>

                </td>
                <td class="text-right">
                    <?php echo $__env->make('includes.caved-buttons', ['cavedBtnArray' => $data['cavedBtn']['casefiles_recent'][$casefile->id],'c'=>'blocked','d'=>'blocked'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    </small>
<?php endif; ?><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/dashboard/cards/recent-casefiles-card.blade.php ENDPATH**/ ?>