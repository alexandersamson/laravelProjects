<h5>Assignable investigators</h5>
<?php if(count($data['investigators']) > 0): ?>
    <?php $__currentLoopData = $data['investigators']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investigator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="d-flex flex-row align-items-center border">
                <div class="mr-auto pl-1">
                        <a class="btn text-sm-left align-self-sm-start btn-sm btn-primary font-weight-light" href="/users/<?php echo e($investigator->id); ?>"><?php echo e($investigator->name); ?></a>
                </div>
                <div class="p-2">
                    <small>
                        Permission: <?php echo e($investigator->permission); ?><br>
                    </small>
                </div>
                <div class="pr-1">
                    <a class="btn text-sm-left align-self-sm-start btn-sm btn-primary font-weight-light selectBtnMulti" data-url="addInvestigators" data-value="<?php echo e($investigator->id); ?>" id="btnRadio<?php echo e($investigator->id); ?>" href="#}">Select this user</a>
                </div>
            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
    <p>No users found</p>
<?php endif; ?>













<?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/modals/includes/investigator-selector.blade.php ENDPATH**/ ?>