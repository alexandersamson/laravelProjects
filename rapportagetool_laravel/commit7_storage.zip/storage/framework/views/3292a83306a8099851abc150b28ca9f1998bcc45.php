
<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-header="HEADER TEST OK" data-body="BODY TEST OK" data-target="#addUserModal">
    Add Investigator
</button>
<?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/casefiles/elements/create/select-investigators.blade.php ENDPATH**/ ?>