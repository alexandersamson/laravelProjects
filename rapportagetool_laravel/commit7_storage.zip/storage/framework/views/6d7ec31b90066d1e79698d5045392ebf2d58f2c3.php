<?php if(count($data['posts'])> 0): ?>
    <small><table class="table table-sm">
        <?php $__currentLoopData = $data['posts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="posts<?php echo e($post->id); ?>">
                <td class="overflow-hidden">
                    <?php echo e(\Illuminate\Support\Str::limit($post->title,27)); ?>

                </td>
                <td class="text-right">

                    <?php if(isset($data['cavedBtn']['posts'][$post->id])): ?>
                        <?php echo $__env->make('includes.caved-buttons', ['cavedBtnArray' => $data['cavedBtn']['posts'][$post->id],'c'=>'blocked'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    </small>
<?php endif; ?><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/dashboard/cards/recent-posts-card.blade.php ENDPATH**/ ?>