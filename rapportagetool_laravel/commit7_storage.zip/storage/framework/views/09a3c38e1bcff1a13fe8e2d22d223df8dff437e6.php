<?php if(isset($cavedBtnArray)): ?>
<span class="btn-group btn-xs-table">
    <?php if($cavedBtnArray['c'] && !isset($c)): ?>
        <a title="Copy to new" href="/copynew/<?php echo e($cavedBtnArray['category']); ?>/<?php echo e($cavedBtnArray['id']); ?>" class="btn btn-sm btn-xs-table btn-outline-info">&nbsp;C&nbsp;</a>
    <?php endif; ?>
    <?php if($cavedBtnArray['a'] && !isset($a)): ?>
        <a title="Approve" href="/approve/<?php echo e($cavedBtnArray['category']); ?>/<?php echo e($cavedBtnArray['id']); ?>" class="btn btn-sm btn-xs-table btn-success">&nbsp;A&nbsp;</a>
    <?php endif; ?>
    <?php if($cavedBtnArray['v'] && !isset($v)): ?>
        <a title="View" href="/<?php echo e($cavedBtnArray['category']); ?>/<?php echo e($cavedBtnArray['id']); ?>" class="btn btn-sm btn-xs-table btn-outline-primary">&nbsp;&nbsp;&nbsp;V&nbsp;&nbsp;&nbsp;</a>
    <?php endif; ?>
    <?php if($cavedBtnArray['e'] && !isset($e)): ?>
        <a title="Edit" href="/<?php echo e($cavedBtnArray['category']); ?>/<?php echo e($cavedBtnArray['id']); ?>/edit" class="btn btn-sm btn-xs-table btn-outline-secondary">&nbsp;E&nbsp;</a>
    <?php endif; ?>
    <?php if($cavedBtnArray['d'] && !isset($d)): ?>
        <a title="Delete" href="#" data-toggle="modal" data-category="<?php echo e($cavedBtnArray['category']); ?>" data-domid="<?php echo e($cavedBtnArray['category']); ?><?php echo e($cavedBtnArray['id']); ?>" data-id="<?php echo e($cavedBtnArray['id']); ?>" data-name="<?php echo e($cavedBtnArray['name']); ?>" data-target="#genericDeleteModal" class="btn btn-sm btn-xs-table btn-outline-danger">&nbsp;D&nbsp;</a>
    <?php endif; ?>
</span>
<?php endif; ?><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/includes/caved-buttons.blade.php ENDPATH**/ ?>