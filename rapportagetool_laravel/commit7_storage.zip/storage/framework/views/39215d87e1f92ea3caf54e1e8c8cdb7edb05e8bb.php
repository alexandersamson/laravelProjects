<?php $__env->startSection('content'); ?>
    <h1>Clients</h1>
    <?php if(count($data['clients']) > 0): ?>
        <?php $__currentLoopData = $data['clients']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <div class="row">
                    <div class="col-md-4 col-sm-4">
                        <p>
                            <?php echo e($client->name); ?> | <?php echo e($client->email); ?> | <?php echo e($client->phone_work); ?>

                        </p>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($data['clients']->links()); ?>

    <?php else: ?>
        <p>No clients found</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/clients/index-include.blade.php ENDPATH**/ ?>