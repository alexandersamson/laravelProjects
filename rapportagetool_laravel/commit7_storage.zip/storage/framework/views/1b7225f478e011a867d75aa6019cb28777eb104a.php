<div class="card bg-light font-weight-lighter text-muted mb-1">
    <div class="row">
        <div class="col-sm-2">
            CaseCode
        </div>
        <div class="col-sm-2">
            Status
        </div>
        <div class="col-sm-2">
            Title
        </div>
        <div class="col-sm-2">
            Clients
        </div>
        <div class="col-sm-4">
            Assigned to
        </div>
    </div>
</div><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/includes/casefile-card-title.blade.php ENDPATH**/ ?>