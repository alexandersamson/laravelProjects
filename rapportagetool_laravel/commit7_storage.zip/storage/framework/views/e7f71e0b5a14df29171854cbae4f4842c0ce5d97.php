<?php $__env->startSection('content'); ?>
    <h1>Users</h1>
    <?php if(count($data['users']) > 0): ?>
        <?php $__currentLoopData = $data['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <div class="row">
                    <div class="col-md-4 col-sm-4">
                        <h4>
                            <a href="/users/<?php echo e($user->id); ?>"><?php echo e($user->name); ?></a>
                        </h4>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <h4>
                            <a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a>
                        </h4>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <small>
                            Permissions: <?php echo e($user->permission); ?><br>
                            Created <?php echo e($user->created_at); ?>

                        </small>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($data['users']->links()); ?>

    <?php else: ?>
        <p>No users found</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/users/index-include.blade.php ENDPATH**/ ?>