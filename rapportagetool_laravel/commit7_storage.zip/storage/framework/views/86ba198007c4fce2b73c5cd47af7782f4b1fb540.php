<div class="row">
    <div class="col-lg-12 col-md-12">
        <div class="card">
            <div class="card-body">
                <div align="center">
                    <img alt="cover image" width="" src="/images/profilepicture/users/<?php echo e($data['user']->id); ?>/profilepicture">
                    <h5 class="card-title"><?php echo e($data['user']->name); ?></h5>
                    <h6 class="card-subtitle mb-2 text-muted"><a href="mailto:<?php echo e($data['user']->email); ?>"><?php echo e($data['user']->email); ?></a> | <a href="tel:<?php echo e($data['user']->phone); ?>"><?php echo e($data['user']->phone); ?></a></h6>
                    <small class="card-subtitle mb-2 text-muted">
                        <?php if((new\App\Http\Controllers\PermissionsController)->getPermissionsTextArray($data['user']->permission) > 0): ?>
                            <?php $__currentLoopData = (new\App\Http\Controllers\PermissionsController)->getPermissionsTextArray($data['user']->permission); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!$loop->first): ?>
                                    |&nbsp;
                                <?php endif; ?>
                                <span class="text-dark"><?php echo e($permission); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </small>
                </div>
                <p class="card-text">

                </p>

            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/users/modals/profile-modal.blade.php ENDPATH**/ ?>