

<?php echo Form::select('case-state', $data['casestates']->pluck('name','id')->toArray(), 1, ['class'=>'form-control']); ?><?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/casefiles/elements/select-case-state-dropdown.blade.php ENDPATH**/ ?>