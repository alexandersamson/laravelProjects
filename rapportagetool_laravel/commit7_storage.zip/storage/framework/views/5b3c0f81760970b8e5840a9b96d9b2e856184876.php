<?php if(count($data['users']) > 0): ?>
    <?php $__currentLoopData = $data['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="<?php echo e($data['containerName']); ?><?php echo e($user[0]->id); ?>">
            <?php echo e(Form::hidden($data['containerName']."[]", $user[0]->id)); ?>

            <span  class="mb-1 btn-group btn-group-sm">
                <button type="button" id="btnInfoModal<?php echo e($data['containerName']); ?><?php echo e($user[0]->id); ?>" class="btn btn-outline-info btnModalInfoUser" data-toggle="modal"
                        data-usertype="<?php echo e($data['containerName']); ?>" data-cmd="infoUser" data-url="<?php echo e($user[0]->id); ?>"
                        data-header="<?php echo e($user[0]->user); ?> | Contact details"  data-target="#genericInfoModal">@</button>
                <button type="button" class="btn btn-secondary"><?php echo e($user[0]->name); ?></button>
                <button type="button" data-url="<?php echo e($data['idPrefix']); ?><?php echo e($data['containerName']); ?><?php echo e($user[0]->id); ?>" data-container="#assigneesContainerA" class="btn btn-outline-danger btnDeleteItem">&times;</button>
            </span>
            <br>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <span class="badge badge-light">Nothing selected</span>
<?php endif; ?>
<?php /**PATH C:\Users\Isa\laravelProjects\rapportagetool_laravel\resources\views/casefiles/elements/select-assignee.blade.php ENDPATH**/ ?>